//
//  ViewController.swift
//  Midterm Calculator
//
//  Created by Dave Scherler on 2/16/15.
//  Copyright (c) 2015 DaveScherler. All rights reserved.
//

import UIKit
import CoreGraphics

class ViewController: UIViewController {
    
    var display = UILabel()
    var equalsButton = UIButton()

    override func viewDidLoad() {
        super.viewDidLoad()
        makeDisplay()
        makeEqualsButton()
        
    }
    
    func makeDisplay() {
        self.view.addSubview(display)
        self.display.setTranslatesAutoresizingMaskIntoConstraints(false)
        self.display.backgroundColor = UIColor.whiteColor()
        //self.display.backgroundColor = UIColor(red:0.92, green:0.91, blue:0.92, alpha:1.0)
        self.display.font = UIFont(name: "Didot", size: 100)
        self.display.text = "0.00" //replace this line later
        self.display.textAlignment = .Right
        self.display.layer.borderColor = UIColor(red:0.03, green:0.03, blue:0.03, alpha:1.0).CGColor!
        self.display.layer.borderWidth = 0.5
        
        let displayWidth = NSLayoutConstraint(item: display,
            attribute: NSLayoutAttribute.Width,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Width,
            multiplier: 1,
            constant: self.view.frame.width * 0.99)
        
        let displayHeight = NSLayoutConstraint(item: display,
            attribute: NSLayoutAttribute.Height,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Height,
            multiplier: 1,
            constant: 150)
        
        let displayLeading = NSLayoutConstraint(item: display,
            attribute: NSLayoutAttribute.Leading,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Leading,
            multiplier: 1,
            constant: self.view.frame.width * 0.005)
        
        let displayTop = NSLayoutConstraint(item: display,
            attribute: NSLayoutAttribute.Top,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Top,
            multiplier: 1,
            constant: 20)
        
        self.view.addConstraints([displayWidth, displayHeight, displayLeading, displayTop])
    }
    
    func makeEqualsButton() {
        self.view.addSubview(equalsButton)
        self.equalsButton.setTranslatesAutoresizingMaskIntoConstraints(false)
        self.equalsButton.backgroundColor = UIColor.blueColor()
        
       let equalsButtonWidth = NSLayoutConstraint(item: equalsButton,
            attribute: NSLayoutAttribute.Width,
            relatedBy: NSLayoutRelation.Equal,
            toItem: display,
            attribute: NSLayoutAttribute.Width,
            multiplier: 1,
            constant: 0)
        
        let equalsButtonLeading = NSLayoutConstraint(item: equalsButton,
            attribute: NSLayoutAttribute.Leading,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Leading,
            multiplier: 1,
            constant: self.view.frame.width * 0.005)
        
        let equalsButtonTop = NSLayoutConstraint(item: equalsButton,
            attribute: NSLayoutAttribute.Top,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Top,
            multiplier: 1,
            constant: self.view.frame.height * 0.90)
        
        let equalsButtonBottom = NSLayoutConstraint(item: equalsButton,
            attribute: NSLayoutAttribute.Bottom,
            relatedBy: NSLayoutRelation.Equal,
            toItem: nil,
            attribute: NSLayoutAttribute.Bottom,
            multiplier: 1,
            constant: self.view.frame.height * 0.05)
        
        self.view.addConstraints([equalsButtonWidth, equalsButtonLeading, equalsButtonTop, equalsButtonBottom])
        
    }
}

