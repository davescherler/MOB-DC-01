//
//  Numeric Buttons.swift
//  Midterm Calculator
//
//  Created by Dave Scherler on 2/17/15.
//  Copyright (c) 2015 DaveScherler. All rights reserved.
//

import Foundation
import UIKit

class NumericButton  {
    var value = 0
    var total = 0
    
    func setValue() {
        
    }
}
