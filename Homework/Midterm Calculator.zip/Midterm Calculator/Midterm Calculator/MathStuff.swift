//
//  MathStuff.swift
//  Midterm Calculator
//
//  Created by Dave Scherler on 2/24/15.
//  Copyright (c) 2015 DaveScherler. All rights reserved.
//

import Foundation

class MathStuff {
    class func add(currentDisplayText: Double, subtotal: Double) -> Double {
        var sum = currentDisplayText + subtotal
        return sum
    }
    
    class func subtract(currentDisplayText: Double, subtotal: Double) -> Double {
        
        if subtotal != 0 {
            let sum = subtotal - currentDisplayText
            return sum
        } else {
            let sum = currentDisplayText - subtotal
            return sum
        }
    }
    
    class func multiply(currentDisplayText: Double, subtotal: Double) -> Double {
       
        if subtotal != 0 {
            let product = currentDisplayText * subtotal
            return product
        } else {
            return currentDisplayText
        }
    }
    
    class func divide(currentDisplayText: Double, subtotal: Double) -> Double {
        
        if subtotal != 0 {
            let dividend = subtotal / currentDisplayText
            return dividend
        } else {
            return currentDisplayText
        }
    }
    
    //solve much performs all the actual math, based on which bool is true.
    
    class func solve(operation: String, displayText: String, subtotal: Double) -> String {
        if operation == "adding" {
            var result = self.add(NSString(string: displayText).doubleValue, subtotal: subtotal)
            println("adding result is \(result)")
            return "\(result)"
            
        } else if operation == "subtracting" {
            var result = self.subtract(NSString(string: displayText).doubleValue, subtotal: subtotal)
            println("subracting result is \(result)")
            return "\(result)"
            
        } else if operation == "multiplying" {
            
            var result = self.multiply(NSString(string: displayText).doubleValue, subtotal: subtotal)
            println("multipling result is \(result)")
            return "\(result)"
            
        } else if operation == "dividing" {
            var result = self.divide(NSString(string: displayText).doubleValue, subtotal: subtotal)
            println("dividing result is \(result)")
            return "\(result)"
            
        } else {
            return "0.00"
        }
    }
}