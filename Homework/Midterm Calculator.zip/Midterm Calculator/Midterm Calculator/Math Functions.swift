//
//  Math Functions.swift
//  Midterm Calculator
//
//  Created by Dave Scherler on 2/17/15.
//  Copyright (c) 2015 DaveScherler. All rights reserved.
//

import Foundation

class NumberButtons {
    
}
